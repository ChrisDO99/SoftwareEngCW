package com.trafficmon;

public interface Crossing {

    Vehicle getVehicle();
    long getTime();
    int getHour();

}
